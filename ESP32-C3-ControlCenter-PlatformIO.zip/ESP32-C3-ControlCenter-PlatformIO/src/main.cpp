/*
  ESP32-C3 SUPER MINI — OLED CONTROL CENTER
  ------------------------------------------
  Board: ESP32-C3 Super Mini
  Arduino board: ESP32C3 Dev Module
  OLED: 128x64 I2C
  SDA = GPIO 8
  SCL = GPIO 9
  BUTTON NEXT = GPIO 1
  BUTTON OK   = GPIO 3

  Libraries:
    U8g2
    WiFi (included with ESP32 Arduino core)

  IMPORTANT:
    This sketch does not use getCpuFrequency().
    For ESP32 core 3.x it uses ESP.getCpuFreqMHz().

  Controls:
    Short NEXT: move down
    Long NEXT: move up
    Short OK:   select / enter
    Long OK:    back
    In pages with actions:
      Short OK can also trigger the page action.
*/

#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <U8g2lib.h>
#include <esp_system.h>

// ============================================================
// PIN CONFIGURATION
// ============================================================

static const uint8_t OLED_SDA = 8;
static const uint8_t OLED_SCL = 9;

static const uint8_t BTN_NEXT = 1;
static const uint8_t BTN_OK   = 3;

static const uint8_t I2C_ADDRESS = 0x3C;

// ============================================================
// DISPLAY
// ============================================================

U8G2_SSD1306_128X64_NONAME_F_HW_I2C oled(
  U8G2_R0,
  U8X8_PIN_NONE,
  OLED_SCL,
  OLED_SDA
);

// ============================================================
// TIMING
// ============================================================

static const uint32_t DEBOUNCE_MS = 35;
static const uint32_t LONG_PRESS_MS = 650;
static const uint32_t VERY_LONG_PRESS_MS = 1800;
static const uint32_t SCREEN_REFRESH_MS = 50;
static const uint32_t CLOCK_REFRESH_MS = 500;
static const uint32_t WIFI_REFRESH_MS = 1000;

// ============================================================
// BUTTON STATE
// ============================================================

struct ButtonState {
  uint8_t pin;
  bool stableState;
  bool lastRawState;
  bool pressed;
  bool shortEvent;
  bool longEvent;
  bool veryLongEvent;
  uint32_t changedAt;
  uint32_t pressedAt;
};

ButtonState btnNext = {
  BTN_NEXT, HIGH, HIGH, false, false, false, false, 0, 0
};

ButtonState btnOk = {
  BTN_OK, HIGH, HIGH, false, false, false, false, 0, 0
};

// ============================================================
// APPLICATION ENUMS
// ============================================================

enum AppPage {
  PAGE_BOOT,
  PAGE_MAIN,
  PAGE_CLOCK,
  PAGE_SYSTEM,
  PAGE_WIFI,
  PAGE_WIFI_DETAIL,
  PAGE_GPIO,
  PAGE_OLED_TEST,
  PAGE_SETTINGS,
  PAGE_ABOUT,
  PAGE_CONFIRM
};

enum MainItem {
  ITEM_CLOCK,
  ITEM_SYSTEM,
  ITEM_WIFI,
  ITEM_GPIO,
  ITEM_OLED_TEST,
  ITEM_SETTINGS,
  ITEM_ABOUT,
  ITEM_COUNT
};

enum SettingsItem {
  SET_CONTRAST,
  SET_INVERT,
  SET_SCROLL_SPEED,
  SET_CPU_INFO,
  SET_RESTART,
  SET_SETTINGS_COUNT
};

enum GpioItem {
  GPIO1_TEST,
  GPIO3_TEST,
  GPIO4_TEST,
  GPIO5_TEST,
  GPIO6_TEST,
  GPIO7_TEST,
  GPIO10_TEST,
  GPIO20_TEST,
  GPIO21_TEST,
  GPIO_ITEM_COUNT
};

// ============================================================
// GLOBAL UI STATE
// ============================================================

AppPage currentPage = PAGE_BOOT;
AppPage previousPage = PAGE_MAIN;

int mainSelection = 0;
int settingsSelection = 0;
int gpioSelection = 0;

bool invertDisplay = false;
uint8_t displayContrast = 255;
uint8_t scrollSpeed = 2;

uint32_t bootStarted = 0;
uint32_t lastDraw = 0;
uint32_t lastClockDraw = 0;
uint32_t lastWifiDraw = 0;

bool wifiScanning = false;
bool wifiScanFinished = false;
int wifiNetworkCount = 0;
int wifiSelected = 0;

String lastAction = "";
uint32_t lastActionAt = 0;

// ============================================================
// SIMPLE RTC-LIKE CLOCK
// ============================================================

uint32_t clockBaseMillis = 0;
uint32_t clockBaseSeconds = 0;

uint32_t currentSeconds() {
  uint32_t elapsed = (millis() - clockBaseMillis) / 1000UL;
  return clockBaseSeconds + elapsed;
}

void setClock(uint32_t secondsValue) {
  clockBaseSeconds = secondsValue;
  clockBaseMillis = millis();
}

void formatTime(char *buffer, size_t len) {
  uint32_t total = currentSeconds();
  uint32_t sec = total % 60;
  uint32_t min = (total / 60) % 60;
  uint32_t hour = (total / 3600) % 24;

  snprintf(
    buffer,
    len,
    "%02lu:%02lu:%02lu",
    (unsigned long)hour,
    (unsigned long)min,
    (unsigned long)sec
  );
}

// ============================================================
// DRAWING HELPERS
// ============================================================

void clearScreen() {
  oled.clearBuffer();
}

void sendScreen() {
  oled.sendBuffer();
}

void drawCentered(const char *text, int y) {
  int width = oled.getStrWidth(text);
  int x = (128 - width) / 2;
  oled.drawStr(x, y, text);
}

void drawHeader(const char *title) {
  oled.setFont(u8g2_font_6x10_tf);
  oled.drawStr(2, 9, title);
  oled.drawHLine(0, 11, 128);
}

void drawFooter(const char *left, const char *right) {
  oled.drawHLine(0, 53, 128);
  oled.setFont(u8g2_font_5x7_tf);
  oled.drawStr(2, 62, left);

  int width = oled.getStrWidth(right);
  oled.drawStr(126 - width, 62, right);
}

void drawArrow(int y) {
  oled.drawTriangle(2, y - 4, 2, y + 4, 7, y);
}

void drawSelectionBar(int y) {
  oled.drawBox(0, y - 9, 128, 11);
  oled.setDrawColor(0);
}

void restoreDrawColor() {
  oled.setDrawColor(1);
}

void drawMenuItem(
  const char *text,
  int y,
  bool selected
) {
  if (selected) {
    oled.drawBox(0, y - 8, 128, 10);
    oled.setDrawColor(0);
    oled.drawStr(5, y, text);
    oled.setDrawColor(1);
  } else {
    oled.drawStr(5, y, text);
  }
}

void drawValueBar(
  int x,
  int y,
  int width,
  int height,
  int value,
  int maximum
) {
  oled.drawFrame(x, y, width, height);

  if (maximum <= 0) {
    return;
  }

  int fill = (value * (width - 2)) / maximum;

  if (fill < 0) {
    fill = 0;
  }

  if (fill > width - 2) {
    fill = width - 2;
  }

  if (fill > 0) {
    oled.drawBox(x + 1, y + 1, fill, height - 2);
  }
}

// ============================================================
// BOOT SCREEN
// ============================================================

void drawBootScreen() {
  clearScreen();

  oled.setFont(u8g2_font_6x10_tf);

  drawCentered("ESP32-C3", 17);
  drawCentered("CONTROL CENTER", 30);

  oled.drawFrame(12, 39, 104, 8);

  uint32_t elapsed = millis() - bootStarted;
  int progress = (int)((elapsed * 100UL) / 1800UL);

  if (progress > 100) {
    progress = 100;
  }

  int width = (progress * 100) / 100;

  if (width > 0) {
    oled.drawBox(14, 41, width, 4);
  }

  oled.setFont(u8g2_font_5x7_tf);
  drawCentered("starting...", 58);

  sendScreen();
}

// ============================================================
// MAIN MENU
// ============================================================

const char *mainItems[ITEM_COUNT] = {
  "Clock",
  "System info",
  "WiFi scanner",
  "GPIO test",
  "OLED test",
  "Settings",
  "About"
};

void drawMainMenu() {
  clearScreen();

  drawHeader("MAIN MENU");

  oled.setFont(u8g2_font_6x10_tf);

  const int visible = 4;

  int first = mainSelection - visible + 1;

  if (first < 0) {
    first = 0;
  }

  if (first > ITEM_COUNT - visible) {
    first = ITEM_COUNT - visible;
  }

  if (first < 0) {
    first = 0;
  }

  for (int i = 0; i < visible; i++) {
    int index = first + i;

    if (index >= ITEM_COUNT) {
      break;
    }

    int y = 21 + i * 10;
    drawMenuItem(mainItems[index], y, index == mainSelection);
  }

  drawFooter("NEXT", "OK");
  sendScreen();
}

// ============================================================
// CLOCK PAGE
// ============================================================

void drawClockPage() {
  clearScreen();

  drawHeader("CLOCK");

  char timeText[16];
  formatTime(timeText, sizeof(timeText));

  oled.setFont(u8g2_font_logisoso24_tn);

  int width = oled.getStrWidth(timeText);
  int x = (128 - width) / 2;

  oled.drawStr(x, 38, timeText);

  oled.setFont(u8g2_font_5x7_tf);
  drawCentered("software clock", 49);
  drawFooter("OK=reset", "LONG=back");

  sendScreen();
}

// ============================================================
// SYSTEM INFORMATION
// ============================================================

void drawSystemPage() {
  clearScreen();

  drawHeader("SYSTEM");

  oled.setFont(u8g2_font_5x7_tf);

  char line[32];

  snprintf(
    line,
    sizeof(line),
    "Chip: ESP32-C3"
  );
  oled.drawStr(2, 19, line);

  snprintf(
    line,
    sizeof(line),
    "CPU: %u MHz",
    ESP.getCpuFreqMHz()
  );
  oled.drawStr(2, 28, line);

  snprintf(
    line,
    sizeof(line),
    "Flash: %lu KB",
    (unsigned long)(ESP.getFlashChipSize() / 1024UL)
  );
  oled.drawStr(2, 37, line);

  snprintf(
    line,
    sizeof(line),
    "Heap: %lu KB",
    (unsigned long)(ESP.getFreeHeap() / 1024UL)
  );
  oled.drawStr(2, 46, line);

  snprintf(
    line,
    sizeof(line),
    "Uptime: %lus",
    (unsigned long)(millis() / 1000UL)
  );
  oled.drawStr(2, 55, line);

  drawFooter("", "LONG=back");

  sendScreen();
}

// ============================================================
// WIFI SCANNER
// ============================================================

void startWifiScan() {
  wifiScanning = true;
  wifiScanFinished = false;
  wifiNetworkCount = 0;
  wifiSelected = 0;

  WiFi.mode(WIFI_STA);
  WiFi.disconnect(false, false);

  delay(20);

  WiFi.scanDelete();
  WiFi.scanNetworks(true, true);

  lastWifiDraw = 0;
}

void updateWifiScan() {
  if (!wifiScanning) {
    return;
  }

  int result = WiFi.scanComplete();

  if (result == WIFI_SCAN_RUNNING) {
    return;
  }

  if (result == WIFI_SCAN_FAILED) {
    wifiScanning = false;
    wifiScanFinished = false;
    wifiNetworkCount = 0;
    return;
  }

  wifiNetworkCount = result;

  if (wifiNetworkCount < 0) {
    wifiNetworkCount = 0;
  }

  wifiScanning = false;
  wifiScanFinished = true;

  if (wifiSelected >= wifiNetworkCount) {
    wifiSelected = max(0, wifiNetworkCount - 1);
  }
}

const char *encryptionName(wifi_auth_mode_t mode);

void drawWifiPage() {
  clearScreen();

  drawHeader("WIFI SCANNER");

  oled.setFont(u8g2_font_5x7_tf);

  if (wifiScanning) {
    drawCentered("Scanning...", 28);

    int dots = (millis() / 300) % 4;

    String d = "";

    for (int i = 0; i < dots; i++) {
      d += ".";
    }

    drawCentered(d.c_str(), 42);

    drawFooter("WAIT", "LONG=back");

    sendScreen();
    return;
  }

  if (!wifiScanFinished) {
    drawCentered("Press OK to scan", 28);
    drawCentered("nearby networks", 40);
    drawFooter("OK=scan", "LONG=back");
    sendScreen();
    return;
  }

  if (wifiNetworkCount == 0) {
    drawCentered("No networks", 28);
    drawCentered("found", 40);
    drawFooter("OK=rescan", "LONG=back");
    sendScreen();
    return;
  }

  const int visible = 4;

  int first = wifiSelected - visible + 1;

  if (first < 0) {
    first = 0;
  }

  if (first > wifiNetworkCount - visible) {
    first = wifiNetworkCount - visible;
  }

  if (first < 0) {
    first = 0;
  }

  for (int i = 0; i < visible; i++) {
    int index = first + i;

    if (index >= wifiNetworkCount) {
      break;
    }

    int y = 19 + i * 10;

    if (index == wifiSelected) {
      oled.drawBox(0, y - 7, 128, 9);
      oled.setDrawColor(0);
    }

    String name = WiFi.SSID(index);

    if (name.length() == 0) {
      name = "<hidden>";
    }

    if (name.length() > 17) {
      name = name.substring(0, 17);
    }

    String row = name;
    row += " ";
    row += String(WiFi.RSSI(index));

    oled.drawStr(3, y, row.c_str());

    if (index == wifiSelected) {
      oled.setDrawColor(1);
    }
  }

  drawFooter("NEXT=move", "OK=details");
  sendScreen();
}

// ============================================================
// WIFI DETAIL
// ============================================================

void drawWifiDetailPage() {
  clearScreen();

  drawHeader("NETWORK");

  if (wifiNetworkCount <= 0 ||
      wifiSelected < 0 ||
      wifiSelected >= wifiNetworkCount) {

    drawCentered("No network", 30);
    drawFooter("", "LONG=back");

    sendScreen();
    return;
  }

  oled.setFont(u8g2_font_5x7_tf);

  String ssid = WiFi.SSID(wifiSelected);
  String bssid = WiFi.BSSIDstr(wifiSelected);

  if (ssid.length() == 0) {
    ssid = "<hidden>";
  }

  oled.drawStr(2, 19, "SSID:");

  if (ssid.length() > 18) {
    ssid = ssid.substring(0, 18);
  }

  oled.drawStr(34, 19, ssid.c_str());

  char line[32];

  snprintf(
    line,
    sizeof(line),
    "RSSI: %d dBm",
    WiFi.RSSI(wifiSelected)
  );
  oled.drawStr(2, 29, line);

  snprintf(
    line,
    sizeof(line),
    "CH: %d",
    WiFi.channel(wifiSelected)
  );
  oled.drawStr(2, 39, line);

  snprintf(
    line,
    sizeof(line),
    "ENC: %s",
    encryptionName(WiFi.encryptionType(wifiSelected))
  );
  oled.drawStr(2, 49, line);

  if (bssid.length() > 17) {
    bssid = bssid.substring(0, 17);
  }

  oled.drawStr(2, 59, bssid.c_str());

  sendScreen();
}

const char *encryptionName(wifi_auth_mode_t mode) {
  switch (mode) {
    case WIFI_AUTH_OPEN:
      return "OPEN";

    case WIFI_AUTH_WEP:
      return "WEP";

    case WIFI_AUTH_WPA_PSK:
      return "WPA";

    case WIFI_AUTH_WPA2_PSK:
      return "WPA2";

    case WIFI_AUTH_WPA_WPA2_PSK:
      return "WPA/WPA2";

    case WIFI_AUTH_WPA2_ENTERPRISE:
      return "WPA2-ENT";

    case WIFI_AUTH_WPA3_PSK:
      return "WPA3";

    case WIFI_AUTH_WPA2_WPA3_PSK:
      return "WPA2/WPA3";

    default:
      return "?";
  }
}

// ============================================================
// GPIO TEST
// ============================================================

const uint8_t gpioPins[GPIO_ITEM_COUNT] = {
  1, 3, 4, 5, 6, 7, 10, 20, 21
};

const char *gpioNames[GPIO_ITEM_COUNT] = {
  "GPIO1",
  "GPIO3",
  "GPIO4",
  "GPIO5",
  "GPIO6",
  "GPIO7",
  "GPIO10",
  "GPIO20",
  "GPIO21"
};

void drawGpioPage() {
  clearScreen();

  drawHeader("GPIO TEST");

  oled.setFont(u8g2_font_6x10_tf);

  const int visible = 4;

  int first = gpioSelection - visible + 1;

  if (first < 0) {
    first = 0;
  }

  if (first > GPIO_ITEM_COUNT - visible) {
    first = GPIO_ITEM_COUNT - visible;
  }

  if (first < 0) {
    first = 0;
  }

  for (int i = 0; i < visible; i++) {
    int index = first + i;

    if (index >= GPIO_ITEM_COUNT) {
      break;
    }

    int y = 20 + i * 10;

    bool selected = index == gpioSelection;

    if (selected) {
      oled.drawBox(0, y - 8, 128, 10);
      oled.setDrawColor(0);
    }

    oled.drawStr(5, y, gpioNames[index]);

    int state = digitalRead(gpioPins[index]);

    oled.drawStr(
      70,
      y,
      state ? "HIGH" : "LOW"
    );

    if (selected) {
      oled.setDrawColor(1);
    }
  }

  drawFooter("NEXT=move", "OK=read");
  sendScreen();
}

void runSelectedGpioTest() {
  if (gpioSelection < 0 ||
      gpioSelection >= GPIO_ITEM_COUNT) {
    return;
  }

  uint8_t pin = gpioPins[gpioSelection];

  if (pin == BTN_NEXT || pin == BTN_OK) {
    lastAction = "button pin";
    lastActionAt = millis();
    return;
  }

  pinMode(pin, INPUT_PULLUP);

  int state = digitalRead(pin);

  lastAction = String(gpioNames[gpioSelection]) +
               (state ? " HIGH" : " LOW");

  lastActionAt = millis();
}

// ============================================================
// OLED TEST
// ============================================================

int oledTestFrame = 0;

void drawOledTestPage() {
  clearScreen();

  drawHeader("OLED TEST");

  oled.setFont(u8g2_font_5x7_tf);

  oled.drawFrame(1, 14, 126, 36);

  for (int x = 5; x < 123; x += 10) {
    oled.drawLine(x, 16, x, 48);
  }

  for (int y = 17; y < 49; y += 8) {
    oled.drawLine(3, y, 124, y);
  }

  int px = 8 + (oledTestFrame % 112);

  oled.drawDisc(px, 31, 3);

  oled.drawStr(3, 61, "PIXEL/GRID TEST");

  sendScreen();
}

void advanceOledTest() {
  oledTestFrame++;

  if (oledTestFrame > 10000) {
    oledTestFrame = 0;
  }
}

// ============================================================
// SETTINGS
// ============================================================

const char *settingsItems[SET_SETTINGS_COUNT] = {
  "Contrast",
  "Invert",
  "Scroll speed",
  "CPU info",
  "Restart"
};

void drawSettingsPage() {
  clearScreen();

  drawHeader("SETTINGS");

  oled.setFont(u8g2_font_6x10_tf);

  const int visible = 4;

  int first = settingsSelection - visible + 1;

  if (first < 0) {
    first = 0;
  }

  if (first > SET_SETTINGS_COUNT - visible) {
    first = SET_SETTINGS_COUNT - visible;
  }

  if (first < 0) {
    first = 0;
  }

  for (int i = 0; i < visible; i++) {
    int index = first + i;

    if (index >= SET_SETTINGS_COUNT) {
      break;
    }

    int y = 20 + i * 10;

    bool selected = index == settingsSelection;

    if (selected) {
      oled.drawBox(0, y - 8, 128, 10);
      oled.setDrawColor(0);
    }

    oled.drawStr(5, y, settingsItems[index]);

    if (index == SET_CONTRAST) {
      char v[8];
      snprintf(v, sizeof(v), "%u", displayContrast);
      int w = oled.getStrWidth(v);
      oled.drawStr(123 - w, y, v);
    }

    if (index == SET_INVERT) {
      oled.drawStr(
        93,
        y,
        invertDisplay ? "ON" : "OFF"
      );
    }

    if (index == SET_SCROLL_SPEED) {
      char v[8];
      snprintf(v, sizeof(v), "%u", scrollSpeed);
      oled.drawStr(112, y, v);
    }

    if (index == SET_CPU_INFO) {
      char v[12];
      snprintf(v, sizeof(v), "%uMHz", ESP.getCpuFreqMHz());
      int w = oled.getStrWidth(v);
      oled.drawStr(123 - w, y, v);
    }

    if (selected) {
      oled.setDrawColor(1);
    }
  }

  drawFooter("NEXT=move", "OK=change");
  sendScreen();
}

void changeSelectedSetting() {
  switch (settingsSelection) {
    case SET_CONTRAST:
      if (displayContrast < 240) {
        displayContrast += 15;
      } else {
        displayContrast = 60;
      }

      oled.setContrast(displayContrast);

      lastAction = "contrast changed";
      break;

    case SET_INVERT:
      invertDisplay = !invertDisplay;
      oled.setContrast(displayContrast);

      if (invertDisplay) {
        oled.setDrawColor(1);
      }

      lastAction = invertDisplay ? "invert ON" : "invert OFF";
      break;

    case SET_SCROLL_SPEED:
      scrollSpeed++;

      if (scrollSpeed > 5) {
        scrollSpeed = 1;
      }

      lastAction = "speed changed";
      break;

    case SET_CPU_INFO:
      lastAction = "CPU " + String(ESP.getCpuFreqMHz()) + "MHz";
      break;

    case SET_RESTART:
      lastAction = "restarting...";
      lastActionAt = millis();

      delay(150);
      ESP.restart();
      break;
  }

  lastActionAt = millis();
}

// ============================================================
// ABOUT
// ============================================================

void drawAboutPage() {
  clearScreen();

  drawHeader("ABOUT");

  oled.setFont(u8g2_font_5x7_tf);

  drawCentered("ESP32-C3", 20);
  drawCentered("OLED CONTROL CENTER", 30);
  drawCentered("Arduino / U8g2", 40);
  drawCentered("SDA 8   SCL 9", 49);

  drawFooter("2026", "LONG=back");

  sendScreen();
}

// ============================================================
// CONFIRMATION / MESSAGE
// ============================================================

void drawMessagePage(const char *title, const char *message) {
  clearScreen();

  drawHeader(title);

  oled.setFont(u8g2_font_6x10_tf);

  drawCentered(message, 33);

  drawFooter("", "OK");

  sendScreen();
}

// ============================================================
// BUTTON PROCESSING
// ============================================================

void updateButton(ButtonState &button) {
  bool raw = digitalRead(button.pin);

  button.shortEvent = false;
  button.longEvent = false;
  button.veryLongEvent = false;

  if (raw != button.lastRawState) {
    button.lastRawState = raw;
    button.changedAt = millis();
  }

  if ((millis() - button.changedAt) >= DEBOUNCE_MS) {
    if (raw != button.stableState) {
      button.stableState = raw;

      if (button.stableState == LOW) {
        button.pressed = true;
        button.pressedAt = millis();
      } else {
        if (button.pressed) {
          uint32_t duration = millis() - button.pressedAt;

          if (duration >= VERY_LONG_PRESS_MS) {
            button.veryLongEvent = true;
          } else if (duration >= LONG_PRESS_MS) {
            button.longEvent = true;
          } else {
            button.shortEvent = true;
          }
        }

        button.pressed = false;
      }
    }
  }
}

void updateButtons() {
  updateButton(btnNext);
  updateButton(btnOk);
}

// ============================================================
// NAVIGATION
// ============================================================

void goBack() {
  switch (currentPage) {
    case PAGE_MAIN:
      break;

    case PAGE_WIFI_DETAIL:
      currentPage = PAGE_WIFI;
      break;

    case PAGE_CLOCK:
    case PAGE_SYSTEM:
    case PAGE_WIFI:
    case PAGE_GPIO:
    case PAGE_OLED_TEST:
    case PAGE_SETTINGS:
    case PAGE_ABOUT:
      currentPage = PAGE_MAIN;
      break;

    default:
      currentPage = PAGE_MAIN;
      break;
  }
}

void openMainSelection() {
  switch (mainSelection) {
    case ITEM_CLOCK:
      currentPage = PAGE_CLOCK;
      break;

    case ITEM_SYSTEM:
      currentPage = PAGE_SYSTEM;
      break;

    case ITEM_WIFI:
      currentPage = PAGE_WIFI;
      wifiScanFinished = false;
      wifiScanning = false;
      break;

    case ITEM_GPIO:
      currentPage = PAGE_GPIO;
      break;

    case ITEM_OLED_TEST:
      currentPage = PAGE_OLED_TEST;
      break;

    case ITEM_SETTINGS:
      currentPage = PAGE_SETTINGS;
      break;

    case ITEM_ABOUT:
      currentPage = PAGE_ABOUT;
      break;
  }
}

void handleMainButtons() {
  if (btnNext.shortEvent) {
    mainSelection++;

    if (mainSelection >= ITEM_COUNT) {
      mainSelection = 0;
    }
  }

  if (btnNext.longEvent) {
    mainSelection--;

    if (mainSelection < 0) {
      mainSelection = ITEM_COUNT - 1;
    }
  }

  if (btnOk.shortEvent) {
    openMainSelection();
  }

  if (btnOk.longEvent) {
    // Already at root; no action.
  }
}

void handleClockButtons() {
  if (btnOk.shortEvent) {
    setClock(0);
    lastAction = "clock reset";
    lastActionAt = millis();
  }

  if (btnOk.longEvent || btnNext.longEvent) {
    goBack();
  }
}

void handleSystemButtons() {
  if (btnOk.longEvent || btnNext.longEvent) {
    goBack();
  }
}

void handleWifiButtons() {
  if (wifiScanning) {
    if (btnOk.longEvent) {
      WiFi.scanDelete();
      wifiScanning = false;
      wifiScanFinished = false;
      goBack();
    }

    return;
  }

  if (btnNext.shortEvent) {
    if (wifiNetworkCount > 0) {
      wifiSelected++;

      if (wifiSelected >= wifiNetworkCount) {
        wifiSelected = 0;
      }
    }
  }

  if (btnNext.longEvent) {
    if (wifiNetworkCount > 0) {
      wifiSelected--;

      if (wifiSelected < 0) {
        wifiSelected = wifiNetworkCount - 1;
      }
    } else {
      goBack();
    }
  }

  if (btnOk.shortEvent) {
    if (!wifiScanFinished) {
      startWifiScan();
    } else if (wifiNetworkCount > 0) {
      currentPage = PAGE_WIFI_DETAIL;
    } else {
      startWifiScan();
    }
  }

  if (btnOk.longEvent) {
    WiFi.scanDelete();
    wifiScanning = false;
    wifiScanFinished = false;
    goBack();
  }
}

void handleWifiDetailButtons() {
  if (btnOk.longEvent || btnNext.longEvent) {
    currentPage = PAGE_WIFI;
  }
}

void handleGpioButtons() {
  if (btnNext.shortEvent) {
    gpioSelection++;

    if (gpioSelection >= GPIO_ITEM_COUNT) {
      gpioSelection = 0;
    }
  }

  if (btnNext.longEvent) {
    gpioSelection--;

    if (gpioSelection < 0) {
      gpioSelection = GPIO_ITEM_COUNT - 1;
    }
  }

  if (btnOk.shortEvent) {
    runSelectedGpioTest();
  }

  if (btnOk.longEvent) {
    goBack();
  }
}

void handleOledTestButtons() {
  if (btnOk.shortEvent) {
    advanceOledTest();
  }

  if (btnOk.longEvent || btnNext.longEvent) {
    goBack();
  }
}

void handleSettingsButtons() {
  if (btnNext.shortEvent) {
    settingsSelection++;

    if (settingsSelection >= SET_SETTINGS_COUNT) {
      settingsSelection = 0;
    }
  }

  if (btnNext.longEvent) {
    settingsSelection--;

    if (settingsSelection < 0) {
      settingsSelection = SET_SETTINGS_COUNT - 1;
    }
  }

  if (btnOk.shortEvent) {
    changeSelectedSetting();
  }

  if (btnOk.longEvent) {
    goBack();
  }
}

void handleAboutButtons() {
  if (btnOk.longEvent || btnNext.longEvent) {
    goBack();
  }
}

void handleInput() {
  updateButtons();

  switch (currentPage) {
    case PAGE_MAIN:
      handleMainButtons();
      break;

    case PAGE_CLOCK:
      handleClockButtons();
      break;

    case PAGE_SYSTEM:
      handleSystemButtons();
      break;

    case PAGE_WIFI:
      handleWifiButtons();
      break;

    case PAGE_WIFI_DETAIL:
      handleWifiDetailButtons();
      break;

    case PAGE_GPIO:
      handleGpioButtons();
      break;

    case PAGE_OLED_TEST:
      handleOledTestButtons();
      break;

    case PAGE_SETTINGS:
      handleSettingsButtons();
      break;

    case PAGE_ABOUT:
      handleAboutButtons();
      break;

    default:
      break;
  }
}

// ============================================================
// STATUS MESSAGE
// ============================================================

void drawTransientMessage() {
  if (lastAction.length() == 0) {
    return;
  }

  if (millis() - lastActionAt > 1200) {
    lastAction = "";
    return;
  }

  oled.drawBox(3, 22, 122, 22);
  oled.setDrawColor(0);

  oled.setFont(u8g2_font_5x7_tf);

  String text = lastAction;

  if (text.length() > 27) {
    text = text.substring(0, 27);
  }

  drawCentered(text.c_str(), 35);

  oled.setDrawColor(1);
}

// ============================================================
// PAGE RENDERER
// ============================================================

void renderCurrentPage() {
  switch (currentPage) {
    case PAGE_BOOT:
      drawBootScreen();
      break;

    case PAGE_MAIN:
      drawMainMenu();
      break;

    case PAGE_CLOCK:
      drawClockPage();
      break;

    case PAGE_SYSTEM:
      drawSystemPage();
      break;

    case PAGE_WIFI:
      drawWifiPage();
      break;

    case PAGE_WIFI_DETAIL:
      drawWifiDetailPage();
      break;

    case PAGE_GPIO:
      drawGpioPage();
      break;

    case PAGE_OLED_TEST:
      drawOledTestPage();
      break;

    case PAGE_SETTINGS:
      drawSettingsPage();
      break;

    case PAGE_ABOUT:
      drawAboutPage();
      break;

    case PAGE_CONFIRM:
      drawMessagePage("MESSAGE", "OK");
      break;
  }
}

// ============================================================
// STARTUP TESTS
// ============================================================

bool testI2CDisplay() {
  Wire.begin(OLED_SDA, OLED_SCL);

  delay(20);

  oled.begin();

  oled.setI2CAddress(I2C_ADDRESS << 1);

  oled.setContrast(displayContrast);

  oled.setFont(u8g2_font_6x10_tf);

  clearScreen();

  drawCentered("OLED OK", 30);
  drawCentered("I2C 0x3C", 43);

  sendScreen();

  delay(700);

  return true;
}

void setupButtons() {
  pinMode(BTN_NEXT, INPUT_PULLUP);
  pinMode(BTN_OK, INPUT_PULLUP);

  btnNext.stableState = digitalRead(BTN_NEXT);
  btnNext.lastRawState = btnNext.stableState;

  btnOk.stableState = digitalRead(BTN_OK);
  btnOk.lastRawState = btnOk.stableState;
}

void setupWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(false, false);
  delay(30);
}

// ============================================================
// OPTIONAL HARDWARE-SAFE GPIO LIST
// ============================================================

bool isSafeUserGpio(uint8_t pin) {
  switch (pin) {
    case 4:
    case 5:
    case 6:
    case 7:
    case 10:
    case 20:
    case 21:
      return true;

    default:
      return false;
  }
}

// ============================================================
// DIAGNOSTIC HELPERS
// ============================================================

void printDiagnostics() {
  Serial.println();
  Serial.println("================================");
  Serial.println("ESP32-C3 CONTROL CENTER");
  Serial.println("================================");

  Serial.print("CPU MHz: ");
  Serial.println(ESP.getCpuFreqMHz());

  Serial.print("Flash bytes: ");
  Serial.println(ESP.getFlashChipSize());

  Serial.print("Free heap: ");
  Serial.println(ESP.getFreeHeap());

  Serial.print("Chip revision: ");
  Serial.println(ESP.getChipRevision());

  Serial.print("SDK: ");
  Serial.println(ESP.getSdkVersion());

  Serial.print("SDA: ");
  Serial.println(OLED_SDA);

  Serial.print("SCL: ");
  Serial.println(OLED_SCL);

  Serial.print("BTN NEXT: ");
  Serial.println(BTN_NEXT);

  Serial.print("BTN OK: ");
  Serial.println(BTN_OK);

  Serial.println("================================");
}

// ============================================================
// SERIAL COMMANDS
// ============================================================

String serialLine;

void processSerialCommand(const String &command) {
  String cmd = command;
  cmd.trim();
  cmd.toLowerCase();

  if (cmd == "help") {
    Serial.println("Commands:");
    Serial.println("  help");
    Serial.println("  info");
    Serial.println("  scan");
    Serial.println("  clock");
    Serial.println("  reset");
    return;
  }

  if (cmd == "info") {
    printDiagnostics();
    return;
  }

  if (cmd == "scan") {
    startWifiScan();
    Serial.println("WiFi scan started");
    return;
  }

  if (cmd == "clock") {
    Serial.print("Clock: ");
    Serial.println(currentSeconds());
    return;
  }

  if (cmd == "reset") {
    Serial.println("Restarting...");
    delay(100);
    ESP.restart();
    return;
  }

  if (cmd.length() > 0) {
    Serial.print("Unknown command: ");
    Serial.println(command);
  }
}

void updateSerial() {
  while (Serial.available()) {
    char c = (char)Serial.read();

    if (c == '\n' || c == '\r') {
      if (serialLine.length() > 0) {
        processSerialCommand(serialLine);
        serialLine = "";
      }
    } else {
      if (serialLine.length() < 80) {
        serialLine += c;
      }
    }
  }
}

// ============================================================
// ANIMATION TICK
// ============================================================

void animationTick() {
  static uint32_t lastAnimation = 0;

  uint32_t interval = 180 / max((int)scrollSpeed, 1);

  if (millis() - lastAnimation < interval) {
    return;
  }

  lastAnimation = millis();

  if (currentPage == PAGE_OLED_TEST) {
    advanceOledTest();
  }
}

// ============================================================
// WIFI TICK
// ============================================================

void wifiTick() {
  if (!wifiScanning) {
    return;
  }

  updateWifiScan();
}

// ============================================================
// RENDER TICK
// ============================================================

void renderTick() {
  if (millis() - lastDraw < SCREEN_REFRESH_MS) {
    return;
  }

  lastDraw = millis();

  renderCurrentPage();
}

// ============================================================
// BOOT LOGIC
// ============================================================

void handleBoot() {
  if (millis() - bootStarted < 1800) {
    return;
  }

  currentPage = PAGE_MAIN;
}

// ============================================================
// SETUP
// ============================================================

void setup() {
  Serial.begin(115200);

  delay(100);

  bootStarted = millis();

  setupButtons();

  testI2CDisplay();

  setupWifi();

  setClock(0);

  printDiagnostics();

  currentPage = PAGE_BOOT;
}

// ============================================================
// LOOP
// ============================================================

void loop() {
  updateSerial();

  handleBoot();

  if (currentPage != PAGE_BOOT) {
    handleInput();
  }

  wifiTick();

  animationTick();

  renderTick();

  delay(1);
}

// ============================================================
// EXTRA UI UTILITIES
// ============================================================

void drawSignalBars(int x, int y, int level) {
  for (int i = 0; i < 4; i++) {
    int h = (i + 1) * 3;

    if (i < level) {
      oled.drawBox(x + i * 5, y - h, 3, h);
    } else {
      oled.drawFrame(x + i * 5, y - h, 3, h);
    }
  }
}

int rssiToBars(int rssi) {
  if (rssi >= -55) {
    return 4;
  }

  if (rssi >= -65) {
    return 3;
  }

  if (rssi >= -75) {
    return 2;
  }

  if (rssi >= -85) {
    return 1;
  }

  return 0;
}

void drawWifiSignalForSelected() {
  if (!wifiScanFinished) {
    return;
  }

  if (wifiSelected < 0 ||
      wifiSelected >= wifiNetworkCount) {
    return;
  }

  int rssi = WiFi.RSSI(wifiSelected);

  drawSignalBars(103, 50, rssiToBars(rssi));
}

void drawProgress(int x, int y, int width, int value) {
  if (value < 0) {
    value = 0;
  }

  if (value > 100) {
    value = 100;
  }

  oled.drawFrame(x, y, width, 7);

  int fill = ((width - 2) * value) / 100;

  if (fill > 0) {
    oled.drawBox(x + 1, y + 1, fill, 5);
  }
}

void drawTinyBattery(int x, int y, int level) {
  oled.drawFrame(x, y, 20, 8);
  oled.drawBox(x + 20, y + 2, 2, 4);

  if (level < 0) {
    level = 0;
  }

  if (level > 100) {
    level = 100;
  }

  int fill = (level * 16) / 100;

  if (fill > 0) {
    oled.drawBox(x + 2, y + 2, fill, 4);
  }
}

// ============================================================
// SAFE VALUE HELPERS
// ============================================================

int wrapIndex(int value, int count) {
  if (count <= 0) {
    return 0;
  }

  while (value < 0) {
    value += count;
  }

  while (value >= count) {
    value -= count;
  }

  return value;
}

void nextMainItem() {
  mainSelection = wrapIndex(
    mainSelection + 1,
    ITEM_COUNT
  );
}

void previousMainItem() {
  mainSelection = wrapIndex(
    mainSelection - 1,
    ITEM_COUNT
  );
}

void nextSettingItem() {
  settingsSelection = wrapIndex(
    settingsSelection + 1,
    SET_SETTINGS_COUNT
  );
}

void previousSettingItem() {
  settingsSelection = wrapIndex(
    settingsSelection - 1,
    SET_SETTINGS_COUNT
  );
}

void nextGpioItem() {
  gpioSelection = wrapIndex(
    gpioSelection + 1,
    GPIO_ITEM_COUNT
  );
}

void previousGpioItem() {
  gpioSelection = wrapIndex(
    gpioSelection - 1,
    GPIO_ITEM_COUNT
  );
}

// ============================================================
// END
// ============================================================
