# ESP32-C3 Control Center

PlatformIO project for ESP32-C3 Super Mini / ESP32-C3 Dev Module.

## Hardware

- OLED 128x64 I2C
- SDA = GPIO 8
- SCL = GPIO 9
- NEXT button = GPIO 1
- OK button = GPIO 3

## Build locally

```bash
pio run
```

The main firmware will be:

```text
.pio/build/esp32-c3-supermini/firmware.bin
```

## Build on GitHub

Push the project to a GitHub repository.

Then open:

**Actions → Build ESP32-C3 firmware → Run workflow**

After the build finishes:

**Actions → completed workflow → Artifacts → ESP32-C3-ControlCenter-firmware**

The artifact contains:
- firmware.bin
- bootloader.bin
- partitions.bin
- firmware.elf
